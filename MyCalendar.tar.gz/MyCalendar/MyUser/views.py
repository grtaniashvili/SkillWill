from django.http import HttpResponse
from MyUser.models import Users


def user(request):
    p = Users.objects.filter(id=1)
    return HttpResponse(p)
