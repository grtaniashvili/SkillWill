from django.urls import path
from MyUser import views

urlpatterns = [
    path('', views.user)
]